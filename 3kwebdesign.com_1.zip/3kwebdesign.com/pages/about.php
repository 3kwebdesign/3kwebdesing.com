<article id="mainPage">
	<h2>O nás</h2>
	<p class="center">
		Jsme skupinou třech lidí o společném zájmu - webové technologie a vývoj v nich. Vytváříme aplikace v jazycích HTML5, CSS3, JavaScriptu a na serverové části v jazyce PHP s použítím databází MySQL a SQLite. U našich projektů striktně dbáme na bezpečnost provedení a komunikaci se zákazníkem. <br />
		Snažíme se v našem oboru jen zlepšovat a dbát na kvalitu svých prací.
	</p>

	<p class="center">
		<i class="fa fa-quote-left fa-pull-left" aria-hidden="true" style="margin-right: 1em;"></i>
		<i>Náš zákazník, náš pán.</i>
	</p>
</article>