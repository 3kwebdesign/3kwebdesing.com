<article id="mainPage">
	<h2>Reference</h2>

	<p class="center">
		Zde můžete vidět výsledky našich dosavadních prací, na které jsme i náležitě hrdí. 
		Ovšem publikujeme zde i naše soukromé projekty, na kterých pracujeme ve svém volném čase.
	</p>

	<div class="reference">
		<div class="item">
			<img src="design/images/stipala.png" />
			
			<div class="info">
				<div class="inner">
					<div class="table">
						<div class="top">
							<h3>Martin Štípala - umělecké truhlářství</h3>
						</div>

						<div class="bottom">
							<a href="http://msdilna.cz" target="_blank">
								<i class="fa fa-link" aria-hidden="true"></i>
							</a>
						</div>
					</div>
				</div>

			</div>
		</div>

		<div class="item">
			<img src="design/images/daperhair.png" />

			<div class="info">
				<div class="inner">
					<div class="table">
						<div class="top">
							<h3>Kadeřnictví Daperhair</h3>
						</div>

						<div class="bottom">
							<a href="http://www.daperhair.com" target="_blank">
								<i class="fa fa-link" aria-hidden="true"></i>
							</a>
						</div>
					</div>
				</div>

			</div>
		</div>

		<div class="item">
			<img src="design/images/klaga.png" />

			<div class="info">
				<div class="inner">
					<div class="table">
						<div class="top">
							<h3>Petr Klaga - klimatizace a tepelná čerpadla</h3>
						</div>

						<div class="bottom">
							<a href="http://klimatizacevsem.cz" target="_blank">
								<i class="fa fa-link" aria-hidden="true"></i>
							</a>
						</div>
					</div>
				</div>

			</div>
		</div>

		<div class="item">
			<img src="design/images/society.png" />

			<div class="info">
				<div class="inner">
					<div class="table">
						<div class="top">
							<h3>Society - sociální síť</h3>
						</div>

						<div class="bottom">
						</div>
					</div>
				</div>

			</div>
		</div>

		<div class="item">
			<img src="design/images/universum.png" />

			<div class="info">
				<div class="inner">
					<div class="table">
						<div class="top">
							<h3>Universum - simulátor gravitace</h3>
						</div>

						<div class="bottom">
							<a href="http://www.daperhair.com/universum" target="_blank">
								<i class="fa fa-link" aria-hidden="true"></i>
							</a>
						</div>
					</div>
				</div>

			</div>
		</div>

		<div class="item">
			<img src="design/images/design_1_screenshot.png" />

			<div class="info">
				<div class="inner">
					<div class="table">
						<div class="top">
							<h3>„Light Green“ design</h3>
						</div>

						<div class="bottom">
							<a href="http://3kwebdesign.com/Designs/1/" target="_blank">
								<i class="fa fa-link" aria-hidden="true"></i>
							</a>
						</div>
					</div>
				</div>

			</div>
		</div>

	</div>
</article>