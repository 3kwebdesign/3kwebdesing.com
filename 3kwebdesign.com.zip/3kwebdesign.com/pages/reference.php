<article id="mainPage">
	<h2>Reference</h2>

	<p class="center">
		Zde můžete vidět výsledky našich dosavadních prací, na které jsme i náležitě hrdí. 
		Ovšem publikujeme zde i naše soukromé projekty, na kterých pracujeme ve svém volném čase.
	</p>

	<div class="reference">
		<div class="item">
			<img src="design/images/stipala.png" />
		</div>

		<div class="item">
			<img src="design/images/daperhair.png" />
		</div>

		<div class="item">
			<img src="design/images/klaga.png" />
		</div>

		<div class="item">
			<img src="design/images/society.png" />
		</div>

		<div class="item">
			<img src="design/images/universum.png" />
		</div>
	</div>
</article>