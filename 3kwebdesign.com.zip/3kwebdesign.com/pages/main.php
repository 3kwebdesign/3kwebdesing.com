<div id="home-page" class="floating-page">
<div id="bottomAll">
	<div class="circleBox">
		<div id="krul-circle" class="circle" style="background: url('./design/images/krul.jpg') no-repeat; background-size: cover;">

			<div class="cover">
				<h2>Daniel Krůl</h2>
			</div>

		</div>

		<div id="konecny-circle" class="circle" style="background: url('./design/images/krul.jpg') no-repeat; background-size: cover;">
			
			<div class="cover">
				<h2>Tomáš Konečný</h2>
			</div>

		</div>

		<div id="kolcava-circle" class="circle" style="background: url('./design/images/kolcava.jpg') no-repeat; background-size: cover;">
			
			<div class="cover">
				<h2>Jan Kolčava</h2>
			</div>

		</div>
	</div>
</div>
</div>

<div id="krul-page" class="floating-page">
	<div class="inner">
		<h2>Daniel Krůl</h2>
		<p class="center">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean placerat. In convallis. Etiam commodo dui eget wisi. Mauris dictum facilisis augue. Proin pede metus, vulputate nec, fermentum fringilla, vehicula vitae, justo. Integer vulputate sem a nibh rutrum consequat. Sed ac dolor sit amet purus malesuada congue. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Integer malesuada. Curabitur vitae diam non enim vestibulum interdum. Praesent dapibus. Mauris dictum facilisis augue. Aliquam in lorem sit amet leo accumsan lacinia. Mauris suscipit, ligula sit amet pharetra semper, nibh ante cursus purus, vel sagittis velit mauris vel metus. Maecenas libero. Curabitur bibendum justo non orci. Aenean placerat. Integer lacinia. <br />
			<i class="fa fa-arrow-left back-button" aria-hidden="true"></i>
		</p>
	</div>
</div>

<div id="kolcava-page" class="floating-page">
	<div class="inner">
		<h2>Jan Kolčava</h2>
		<p class="center">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean placerat. In convallis. Etiam commodo dui eget wisi. Mauris dictum facilisis augue. Proin pede metus, vulputate nec, fermentum fringilla, vehicula vitae, justo. Integer vulputate sem a nibh rutrum consequat. Sed ac dolor sit amet purus malesuada congue. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Integer malesuada. Curabitur vitae diam non enim vestibulum interdum. Praesent dapibus. Mauris dictum facilisis augue. Aliquam in lorem sit amet leo accumsan lacinia. Mauris suscipit, ligula sit amet pharetra semper, nibh ante cursus purus, vel sagittis velit mauris vel metus. Maecenas libero. Curabitur bibendum justo non orci. Aenean placerat. Integer lacinia. <br />
			<i class="fa fa-arrow-left back-button" aria-hidden="true"></i>
		</p>
	</div>
</div>

<div id="konecny-page" class="floating-page">
	<div class="inner">
		<h2>Tomáš Konečný</h2>
		<p class="center">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean placerat. In convallis. Etiam commodo dui eget wisi. Mauris dictum facilisis augue. Proin pede metus, vulputate nec, fermentum fringilla, vehicula vitae, justo. Integer vulputate sem a nibh rutrum consequat. Sed ac dolor sit amet purus malesuada congue. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Integer malesuada. Curabitur vitae diam non enim vestibulum interdum. Praesent dapibus. Mauris dictum facilisis augue. Aliquam in lorem sit amet leo accumsan lacinia. Mauris suscipit, ligula sit amet pharetra semper, nibh ante cursus purus, vel sagittis velit mauris vel metus. Maecenas libero. Curabitur bibendum justo non orci. Aenean placerat. Integer lacinia. <br />
			<i class="fa fa-arrow-left back-button" aria-hidden="true"></i>
		</p>
	</div>
</div>